﻿using UnityEngine;
using System.Collections;

public class SaveDoor : MonoBehaviour {

	public GameObject DOOR;
	public string answer;

}
