﻿using UnityEngine;
using System.Collections;

public class SceneLoadScript : MonoBehaviour {
	
	public void SceneLoad (){
		Application.LoadLevel ("base_test");
	}
}