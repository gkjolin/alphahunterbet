﻿using UnityEngine;
using System.Collections;

public class FirstPlayerChild : FirstPlayer {

}
