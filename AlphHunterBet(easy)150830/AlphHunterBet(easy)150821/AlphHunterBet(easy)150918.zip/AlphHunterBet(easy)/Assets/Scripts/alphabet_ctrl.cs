﻿using UnityEngine;
using System.Collections;

public class alphabet_ctrl : MonoBehaviour {
	public Transform A;
	public Transform B;
	public Transform C;
	public Transform D;
	public

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
