﻿using UnityEngine;
using System.Collections;

public class Door_ctrl : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {

	}
	//github_test;
	//private GameObject target;
	//void Awake()
	//{
	//	target = GameObject.Find("DOOR");
	//	target.SetActive(false);
	//}
	

}
