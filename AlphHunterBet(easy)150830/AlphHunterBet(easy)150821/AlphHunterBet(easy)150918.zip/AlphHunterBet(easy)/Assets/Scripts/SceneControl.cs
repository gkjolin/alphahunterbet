﻿using UnityEngine;
using System.Collections;

public class SceneControl : MonoBehaviour {

	// Use this for initialization
//public int LoadCurrentStage(int StageNumber)
//	{






}
